# CHECKLIST

Generated/maintained alongside `TASKS.json`.

## P00 — Baseline & audit
- [ ] P00-T01 Branch and baseline snapshot
- [ ] P00-T02 Behavior/route regression baseline
- [ ] P00-T03 Security/RLS/secret audit
- [ ] P00-T04 Asset/performance inventory

## P01 — Domain
- [ ] P01-T01 Typed service catalog
- [ ] P01-T02 Order schema and compatibility adapter

## P02 — Secure booking
- [ ] P02-T01 Secure order API
- [ ] P02-T02 Harden Telegram
- [ ] P02-T03 Client cutover
- [ ] P02-T04 RLS lockdown

## P03 — Frontend foundation
- [ ] P03-T01 React/Vite/TypeScript shell
- [ ] P03-T02 Accessible booking without WebGL

## P04 — 3D assets
- [ ] P04-T01 Licensed source asset
- [ ] P04-T02 Optimized GLB/textures/poster

## P05 — 3D experience
- [ ] P05-T01 Adaptive scene
- [ ] P05-T02 Story + services + booking

## P06 — Admin
- [ ] P06-T01 Incremental admin migration

## P07 — Quality gate
- [ ] P07-T01 Full release gate

## P08 — Cutover
- [ ] P08-T01 Preview/canary/production

## P09 — Handover
- [ ] P09-T01 Handover/closeout
